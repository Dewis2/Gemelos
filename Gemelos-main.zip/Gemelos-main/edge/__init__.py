"""Edge data collection package."""
