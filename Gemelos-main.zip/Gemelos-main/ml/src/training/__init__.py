"""Model training entry points."""
